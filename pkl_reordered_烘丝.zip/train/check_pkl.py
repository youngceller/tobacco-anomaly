import numpy as np
import sys

def check_pkl(file_path):
    # Read the pkl file
    arr = np.load(file_path, allow_pickle=True)
    
    # Print the shape
    print(f"\nShape of the array: {arr.shape}")
    
    # Print the first 10 rows
    print("\nFirst 10 rows of the array:")
    print(arr[:10])
    
    # Print the data type
    print(f"\nData type: {arr.dtype}")

if __name__ == "__main__":
    # Use the first pkl file as an example
    file_path = "D线_云烟(软珍品)2号模组_99_train.pkl"
    check_pkl(file_path) 