import os
import glob
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.widgets import CheckButtons, RangeSlider, Button
import pickle
from matplotlib.colors import to_rgba

# 移除中文字体设置
plt.rcParams['axes.unicode_minus'] = False

# 获取所有特征和标签文件
feature_files = sorted([f for f in glob.glob("*_test.pkl") if not f.endswith("_label.pkl")])
label_files = sorted(glob.glob("*_label.pkl"))

# 读取所有数据
all_features = []
all_labels = []

for feature_file, label_file in zip(feature_files, label_files):
    feature_data = pickle.load(open(feature_file, 'rb'))
    label_data = pickle.load(open(label_file, 'rb'))
    all_features.append(feature_data)
    # 确保标签是一维数组
    all_labels.append(label_data.ravel())

# 计算标准化后的特征
all_features_normalized = []
for feature_data in all_features:
    # 对每个特征进行标准化
    feature_normalized = np.zeros_like(feature_data)
    for i in range(feature_data.shape[1]):
        mean = np.mean(feature_data[:, i])
        std = np.std(feature_data[:, i])
        if std != 0:
            feature_normalized[:, i] = (feature_data[:, i] - mean) / std
        else:
            feature_normalized[:, i] = feature_data[:, i] - mean
    all_features_normalized.append(feature_normalized)

# 合并所有数据
def merge_data(features_list, labels_list):
    # 计算每个文件的长度
    lengths = [len(f) for f in features_list]
    total_length = sum(lengths)
    
    # 创建合并后的数组
    merged_features = np.zeros((total_length, features_list[0].shape[1]))
    merged_labels = np.zeros(total_length)
    
    # 记录每个文件的起始位置
    start_positions = [0]
    current_pos = 0
    
    # 合并数据
    for i, (features, labels) in enumerate(zip(features_list, labels_list)):
        end_pos = current_pos + len(features)
        merged_features[current_pos:end_pos] = features
        merged_labels[current_pos:end_pos] = labels
        current_pos = end_pos
        if i < len(features_list) - 1:
            start_positions.append(current_pos)
    
    return merged_features, merged_labels, start_positions

# 创建主图形
fig = plt.figure(figsize=(15, 8))
plt.subplots_adjust(left=0.25, bottom=0.25)

# 创建主绘图区域
ax = plt.subplot(111)
feature_visibility = [True] * all_features[0].shape[1]
time_range = [0, sum(len(f) for f in all_features)]
is_normalized = False

# 初始绘图
def plot_data():
    ax.clear()
    
    # 获取当前要使用的数据集（原始或标准化）
    features_to_use = all_features_normalized if is_normalized else all_features
    
    # 合并数据
    merged_features, merged_labels, start_positions = merge_data(features_to_use, all_labels)
    
    # 绘制特征曲线
    for i in range(merged_features.shape[1]):
        if feature_visibility[i]:
            line, = ax.plot(merged_features[:, i], label=f'Feature {i+1}', alpha=0.8, linewidth=1)
    
    # 添加标签区域
    ylim = ax.get_ylim()
    for i, label in enumerate(merged_labels):
        if label == 1:
            ax.add_patch(Rectangle((i, ylim[0]),
                                 1,
                                 ylim[1] - ylim[0],
                                 facecolor='red',
                                 alpha=0.2))
    
    # 添加文件分隔线
    for pos in start_positions[1:]:  # 跳过第一个位置（0）
        ax.axvline(x=pos, color='gray', linestyle='--', alpha=0.5)
    
    ax.set_xlim(time_range)
    ax.set_title(f"Merged Data ({'Normalized' if is_normalized else 'Original'})")
    ax.grid(True, alpha=0.3)
    ax.set_xlabel('Time Points')
    ax.set_ylabel('Feature Values')
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
    plt.draw()

# 创建特征选择复选框
rax_features = plt.axes([0.05, 0.4, 0.15, 0.5])
feature_names = [f'Feature {i+1}' for i in range(all_features[0].shape[1])]
check_features = CheckButtons(rax_features, feature_names, [True] * len(feature_names))

def func_features(label):
    index = feature_names.index(label)
    feature_visibility[index] = not feature_visibility[index]
    plot_data()
check_features.on_clicked(func_features)

# 创建时间范围滑块
rax_time = plt.axes([0.25, 0.1, 0.5, 0.03])
total_length = sum(len(f) for f in all_features)
time_slider = RangeSlider(rax_time, 'Time Range', 0, total_length, valinit=(0, total_length))

def update_range(val):
    global time_range
    time_range = [int(val[0]), int(val[1])]
    plot_data()
time_slider.on_changed(update_range)

# 创建标准化切换按钮
rax_norm = plt.axes([0.25, 0.02, 0.1, 0.04])
btn_norm = Button(rax_norm, 'Toggle Normalization')

def toggle_normalization(event):
    global is_normalized
    is_normalized = not is_normalized
    plot_data()

btn_norm.on_clicked(toggle_normalization)

# 初始绘图
plot_data()
plt.show() 